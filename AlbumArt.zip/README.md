# lively-album-art
Simple album art wallpaper for Lively Wallpaper

To install, download the latest release and drag the zip file into the Lively Wallpaper window.